using UnityEngine;
using UnityEngine.Events;

[RequireComponent(typeof(UniqueID))]

public class ShopKeeper : MonoBehaviour, IInteractable
{
    [SerializeField] private ShopItemList _shopItemsHelp;
    [SerializeField] private ShopSystem _shopSystem;

    public static UnityAction<ShopSystem, PlayerInventoryHolder> OnShopWindowRequeste;
    public UnityAction<IInteractable> OnInteractionComplite { get; set; }
    
    private void Awake() 
    {
        // _shopSystem = new ShopSystem(_shopItemsHelp.Items.Count, _shopItemsHelp.MaxAllowedGold, _shopItemsHelp.BuyMarkUp, _shopItemsHelp.SellMarkUp);
    
        // foreach (var item in _shopItemsHelp.Items)
        // {
        //     Debug.Log($"{item.itemData.DisplayName}: {item.Amount}");
        //     _shopSystem.AddToShop(item.itemData, item.Amount);
        // }
    }

    public void Interact(PlayerInteraction interactor, out bool interactSuccessful)
    {
        var playerInv = interactor.GetComponent<PlayerInventoryHolder>();

        if (playerInv != null)
        {
            OnShopWindowRequeste?.Invoke(_shopSystem, playerInv);
            interactSuccessful = true;
        }
        else
        {
            interactSuccessful = false;
            Debug.LogError("Player inventory not found");
        }
    }

    public void EndInteraction()
    {
        
    }
}
