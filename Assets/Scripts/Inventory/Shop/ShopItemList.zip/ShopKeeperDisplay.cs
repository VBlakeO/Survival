using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using TMPro;

public class ShopKeeperDisplay : MonoBehaviour
{
    // [SerializeField] private ShopSlotUI _shopSlotPrefab = null;

    // [SerializeField] private TextMeshProUGUI _playerGoldText = null;
    // [SerializeField] private Button _buyButton = null;

    // [Header("Item Preview Section")]
    // [SerializeField] private Image _itemPreviewSprite = null;
    // [SerializeField] private TextMeshProUGUI _itemPreviewName = null;
    // [SerializeField] private TextMeshProUGUI _itemPreviewDescription = null;
    // [Space]

    // [SerializeField] private GameObject _itemListContentPanel = null;
}
