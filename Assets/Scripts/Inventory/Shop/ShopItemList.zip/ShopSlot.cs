[System.Serializable]
public class ShopSlot : ItemSlot
{
    public ShopSlot()
    {
        ClearSlot();
    }
}
